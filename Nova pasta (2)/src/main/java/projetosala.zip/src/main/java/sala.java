public class sala {
    private int capacidade;
    private String tipo;
    private boolean disponivel;

    public sala() {
        // Construtor sem parâmetro
    }

    public sala(int capacidade, String tipo, boolean disponivel) {
        this.capacidade = capacidade;
        this.tipo = tipo;
        this.disponivel = disponivel;
    }

    // Métodos get e set para capacidade
    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    // Métodos get e set para tipo
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    // Métodos get e set para disponivel
    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
}
