public class Main {
    public static void main(String[] args) {
        // Criando uma instância da classe Sala
        sala minhaSala = new sala(50, "Auditório", true);

        // Acessando os atributos usando os métodos get
        System.out.println("Capacidade da sala: " + minhaSala.getCapacidade());
        System.out.println("Tipo de sala: " + minhaSala.getTipo());
        System.out.println("Disponibilidade da sala: " + minhaSala.isDisponivel());

        // Modificando os atributos usando os métodos set
        minhaSala.setCapacidade(60);
        minhaSala.setTipo("Sala de Aula");
        minhaSala.setDisponivel(false);

        // Acessando os atributos modificados
        System.out.println("Nova capacidade da sala: " + minhaSala.getCapacidade());
        System.out.println("Novo tipo de sala: " + minhaSala.getTipo());
        System.out.println("Nova disponibilidade da sala: " + minhaSala.isDisponivel());
    }
}


